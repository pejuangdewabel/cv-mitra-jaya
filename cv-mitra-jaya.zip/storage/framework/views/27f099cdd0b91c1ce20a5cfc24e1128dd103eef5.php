<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan Penjualan CV Mitra Jaya</title>

    <link href="<?php echo e(asset('assets/backend/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>

<body onload="window.print()">
    <h3 class="text-center">Laporan Penjualan <br> CV Mitra Jaya</h3>
    <h6 class="text-center">
        Tanggal <?php echo e(tanggal_indonesia($dateStart, false)); ?>

        s/d
        Tanggal <?php echo e(tanggal_indonesia($dateEnd, false)); ?>

    </h6>
    <hr>

    <table class="table table-bordered">
        <thead class="text-center">
            <tr>
                <th width="5%" rowspan="2">No</th>
                <th scope="col" rowspan="2">Invoice</th>
                <th scope="col" rowspan="2">Tanggal Transaksi</th>
                <th scope="col" rowspan="2">Nama Pelanggan</th>
                <th scope="col" rowspan="2">Total</th>
                <th scope="col" colspan="3">Detail Pembelian</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dataTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $detail = App\DetailTransaksi::with(['relasi_produk_detail'])
                        ->where('transaksi_id', $dT->id)
                        ->get();
                ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($dT->invoice); ?></td>
                    <td><?php echo e(tanggal_indonesia(date('Y-m-d', strtotime($dT->created_at)))); ?></td>
                    <td><?php echo e($dT->relasi_user->nama); ?></td>
                    <td><?php echo e(format_uang($dT->total)); ?></td>
                    <td>
                    <td>
                        <table>
                            <tr>
                                <td>

                                </td>
                            </tr>

                        </table>
                        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <?php echo e($d->relasi_produk_detail->desc); ?>

                                | <?php echo e($d->jumlah); ?> | <?php echo e(format_uang($d->sub_total)); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/pages/laporan/print.blade.php ENDPATH**/ ?>