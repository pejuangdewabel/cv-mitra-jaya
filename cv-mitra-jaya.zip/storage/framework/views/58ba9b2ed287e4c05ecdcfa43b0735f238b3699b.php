<?php $__env->startPush('after-link'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>PRODUK | SISTEM MANAJEMEN PEMESANAN CV MITRA JAYA</h1>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-12">
                    <div class="card top-selling">
                        <div class="card-body pb-0">
                            <div class="card-title">
                                <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-primary btn-sm">
                                    <i class="bi bi-plus-circle"></i>
                                    Tambah Data
                                </a>
                            </div>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Kategori Produk</th>
                                        <th scope="col">Nama Produk</th>
                                        <th scope="col">Waktu Pengerjaan</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Foto</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dataProduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($dP->relasi_kategori->nama); ?></td>
                                            <td><?php echo e($dP->nama); ?></td>
                                            <td><?php echo e($dP->waktu_pengerjaan); ?> Hari</td>
                                            <td>
                                                <?php if($dP->status == 1): ?>
                                                    <span class="badge bg-primary">Aktif</span>
                                                <?php elseif($dP->status == 2): ?>
                                                    <span class="badge bg-danger">Tidak Aktif</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <img src="<?php echo e(Storage::url($dP->foto)); ?>" class="img-thumbnail"
                                                    style="max-width: 200px !important">
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('produk.show', Crypt::encryptString($dP->id))); ?>"
                                                    class="btn btn-success" title="Detail">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <br>
                                                <br>
                                                <a href="<?php echo e(route('produk.edit', Crypt::encryptString($dP->id))); ?>"
                                                    class="btn btn-warning">
                                                    <i class="bi bi-pencil-fill"></i>
                                                </a>
                                                <br>
                                                <br>
                                                <form action="<?php echo e(route('produk.destroy', Crypt::encryptString($dP->id))); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/pages/produk/index.blade.php ENDPATH**/ ?>