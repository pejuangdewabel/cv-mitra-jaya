<?php $__env->startPush('after-link'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>TRANSAKSI | SISTEM MANAJEMEN PEMESANAN CV MITRA JAYA</h1>
    </div>
    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('transaksi.index')); ?>" class="btn btn-success btn-sm">
                            <i class="bi bi-arrow-left-circle"></i>
                            Kembali
                        </a>
                        <?php if(Session::has('user_id')): ?>
                            <a href="<?php echo e(route('transaksi.show', session()->get('user_id'))); ?>"
                                class="btn btn-warning btn-sm">
                                <i class="bi bi-arrow-left-circle"></i>
                                RESET
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Form Tambah Transaksi Pemesanan</h5>

                        <!-- Floating Labels Form -->
                        <form class="row g-3" method="POST" action="<?php echo e(route('transaksi.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-6">
                                <?php if(Session::has('user_id')): ?>
                                    <div class="form-floating">
                                        <?php
                                            $dataUser2 = App\User::where('id', session()->get('user_id'))->first();
                                        ?>
                                        <input type="text" value="<?php echo e($dataUser2->nama); ?>" class="form-control" readonly>
                                        <input type="hidden" value="<?php echo e(session()->get('user_id')); ?>" name="user_id">
                                        <label for="jumlah">Nama User</label>
                                    </div>
                                <?php else: ?>
                                    <div class="form-floating">
                                        <select name="user_id" id="user_id" class="form-select js-example-basic-single"
                                            required>
                                            <option disabled selected></option>
                                            <?php $__currentLoopData = $dataUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dU): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dU->id); ?>"><?php echo e($dU->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        
                                        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-exclamation-octagon me-1"></i>
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <select name="produk_id" id="produk_id" class="form-select js-example-basic-single"
                                        required>
                                        <option disabled selected></option>
                                        <?php $__currentLoopData = $dataProduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dP->id); ?>"><?php echo e($dP->produk->nama); ?> |
                                                <?php echo e($dP->desc); ?> | <?php echo e(format_uang($dP->price)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                    <?php $__errorArgs = ['produk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="badge bg-danger">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-floating">
                                    <input type="number" class="form-control" name="size1" id="size1"
                                        placeholder="Size Awal" required value="0">
                                    <label for="size1">Panjang</label>
                                    <?php $__errorArgs = ['size1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="badge bg-danger">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-floating">
                                    <input type="number" class="form-control" name="size2" id="size2"
                                        placeholder="Size Akhir" required value="0">
                                    <label for="size2">Lebar</label>
                                    <?php $__errorArgs = ['size2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="badge bg-danger">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <input type="number" class="form-control" name="jumlah" id="jumlah"
                                        placeholder="Jumlah" required value="<?php echo e(old('jumlah')); ?>">
                                    <label for="jumlah">Jumlah</label>
                                    <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="badge bg-danger">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <input type="file" class="form-control" name="file_desain" id="file_desain"
                                        placeholder="FIie Desain">
                                    <label for="file_desain">File Desain</label>
                                    <?php $__errorArgs = ['file_desain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="badge bg-danger">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary w-100">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="card top-selling">
                    <div class="card-body pb-0">
                        <h5 class="card-title">Detail Transaksi
                            <?php if(Session::has('user_id')): ?>
                                <?php
                                    $dataUser = App\User::where('id', session()->get('user_id'))->first();
                                ?>
                                <strong>
                                    : <?php echo e($dataUser->nama); ?>

                                </strong>
                            <?php else: ?>
                            <?php endif; ?>
                        </h5>

                        <table class="table table-borderless">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Produk</th>
                                    <th scope="col">Jumlah</th>
                                    <th scope="col">Sub Total</th>
                                    <th scope="col">File Desain</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(Session::has('user_id')): ?>
                                    <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row">
                                                <?php echo e($loop->iteration); ?>

                                            </th>
                                            <td>
                                                <?php echo e($k->relasi_produk_detail->desc); ?>

                                            </td>
                                            <td>
                                                <?php echo e($k->jumlah); ?>

                                            </td>
                                            <td class="fw-bold text-right">
                                                <?php echo e(format_uang($k->sub_total)); ?>

                                            </td>
                                            <td>
                                                <?php if($k->file_desain != null): ?>
                                                    <form action="<?php echo e(route('download-foto-desain-keranjang')); ?>"
                                                        method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id"
                                                            value="<?php echo e(Crypt::encryptString($k->id)); ?>">
                                                        <button type="submit" class="btn btn-success btn-sm"
                                                            target="_blank">
                                                            <i class="bi bi-capslock-fill"></i>
                                                            DOWNLOAD FILE</button>
                                                    </form>
                                                <?php else: ?>
                                                    ---
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <form
                                                    action="<?php echo e(route('detail-transaksi.destroy', Crypt::encryptString($k->id))); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="3" class="fw-bold text-left">Total Pembayaran</td>
                                        <td class="fw-bold text-right"><?php echo e(format_uang($countKeranjang)); ?></td>
                                    </tr>
                                <?php else: ?>
                                    <tr>
                                        <th>
                                            ---
                                        </th>
                                        <td>
                                            ---
                                        </td>
                                        <td>
                                            ---
                                        </td>
                                        <td>
                                            ---
                                        </td>
                                        <td>
                                            ---
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <hr>
                        <?php if(Session::has('user_id')): ?>
                            <form class="row g-3"
                                action="<?php echo e(route('transaksi.update', Crypt::encryptString(session()->get('user_id')))); ?>"
                                method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" name="bayar" id="bayar"
                                            placeholder="Uang Bayar" required>
                                        <label for="file_desain">Uang Bayar</label>
                                    </div>
                                </div>
                                <button class="btn btn-success w-100">SELESAIKAN TRANSAKSI</button>
                            </form>
                        <?php else: ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-script'); ?>
    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI="
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#user_id').select2({
                placeholder: "Pilih User",
                allowClear: true,
                width: 'resolve',
                theme: "classic"
            });
            $('#produk_id').select2({
                placeholder: "Pilih Produk",
                allowClear: true,
                width: 'resolve',
                theme: "classic"
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/pages/transaksi/create.blade.php ENDPATH**/ ?>