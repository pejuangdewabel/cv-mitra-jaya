<?php $__env->startPush('after-link'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="login header bg-navy">
        <div class="container">
            <div class="row row-cols-md-12 row-cols-1 d-flex justify-content-center align-items-center hero">
                <div class="col-md-6">
                    <div class="hero-headline text-start">
                        Bergabung Dengan Pelanggan Lainnya
                        <br class="d-none d-md-block" />
                    </div>
                    <p class="hero-paragraph text-start">
                        Daftar Sekarang Secara Gratis
                    </p>
                </div>
                <div class="col-md-6">
                    <form action="<?php echo e(route('post-register')); ?>" method="POST"
                        class="form-login d-flex flex-column mt-4 mt-md-0">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex flex-column align-items-start">
                            <label for="first_name" class="form-label">
                                Nama Lengkap
                            </label>
                            <input type="text" placeholder="Nama Lengkap" class="form-control" id="nama"
                                name="nama" value="<?php echo e(old('nama')); ?>">
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="badge bg-danger">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-flex flex-column align-items-start">
                            <label for="last_name" class="form-label">
                                Nomor Handphone
                            </label>
                            <input type="text" placeholder="Nomor Handphone" class="form-control" id="no_telp"
                                name="no_telp" value="<?php echo e(old('no_telp')); ?>">
                            <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="badge bg-danger">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-flex flex-column align-items-start">
                            <label for="email_address" class="form-label">
                                Email
                            </label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email"
                                value="<?php echo e(old('email')); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="badge bg-danger">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- Password -->
                        <div class="d-flex flex-column align-items-start">
                            <label for="password" class="form-label">
                                Password (6 Karakter)
                            </label>
                            <input type="password" class="form-control" id="password" name="password"
                                placeholder="Password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="badge bg-danger">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-flex flex-column align-items-start">
                            <label for="role" class="form-label">
                                Konfirmasi Password
                            </label>
                            <input type="password" class="form-control" id="confirmPassword" name="confirmPassword"
                                placeholder="Konfirmasi Password">
                            <?php $__errorArgs = ['confirmPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="badge bg-danger">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-flex flex-column align-items-start">
                            <label for="role" class="form-label">
                                Captcha Wajib Diisi
                            </label>
                            <strong>
                                <label for="answerCaptcha" class="form-label text-danger" id="questionCaptcha">
                                </label>
                            </strong>

                            <input type="text" class="form-control" id="answerCaptcha" name="answerCaptcha"
                                placeholder="Captcha">
                            <?php $__errorArgs = ['answerCaptcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="badge bg-danger">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <input type="hidden" name="a" id="a" value="">
                        <input type="hidden" name="b" id="b" value="">
                        <div class="d-grid mt-2">
                            <button class="btn-green" type="submit">
                                DAFTAR
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
    <script>
        $(document).ready(function() {
            const a = (Math.random() * 10);
            const b = (Math.random() * 10);
            $('#questionCaptcha').text(parseInt(a) + '+' + parseInt(b) + ' ?');
            $('#a').attr('value', parseInt(a));
            $('#b').attr('value', parseInt(b));
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/frontend/pages/auth/register.blade.php ENDPATH**/ ?>