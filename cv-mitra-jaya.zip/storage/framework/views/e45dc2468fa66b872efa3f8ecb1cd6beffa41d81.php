<?php $__env->startPush('after-link'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content1'); ?>
    <div class="hero">
        <div class="hero-headline">
            <span class="text-gradient-blue"> CV MITRA
                JAYA</span> <br class="d-none d-lg-block" />
        </div>
        <p class="hero-paragraph"> Pelayanan jasa kami pencetakan produk.
            <br>
            Pekerjaan kami dilakukan oleh tenaga profesional yang ahli dalam bidang
            nya.
        </p>
        <div class="row">
            <div class="col-md-12">
                <a href="#grow-today" class="btn-green">
                    CARI PRODUK
                </a>
            </div>
        </div>
    </div>
    <div class="d-flex flex-row flex-nowrap justify-content-center align-items-center gap-5 header-image">
        <img src="<?php echo e(Storage::url($about->hero)); ?>" alt="img-hero" class="img-2" />
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="brand-partner text-center">
        <h3 class="text-gradient-blue">KATEGORI PRODUK</h3>
        <br class="d-none d-md-block" />
        <div class="d-flex flex-row flex-wrap justify-content-center align-items-center">
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(Storage::url($k->icon)); ?>" style="max-width: 100px !important" title="<?php echo e($k->nama); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            
            
        </div>
    </section>

    <section class="grow-today">
        <div class="container">
            <div class="sub-title mb-1" id="grow-today">
                <span class="text-gradient-pink">PRODUK KAMI</span>
            </div>
            <div class="title">
                Berbagai macam produk percetakan
            </div>
            <div class="mt-5 row gap">
                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="card-grow h-100">
                            <span class="badge-pricing"><?php echo e(format_uang($p->price)); ?></span>
                            <img src="<?php echo e(Storage::url($p->produk->foto)); ?>" alt="semina" />
                            <div class="card-content">
                                <div class="card-title">
                                    <?php echo e($p->desc); ?>

                                </div>
                                <div class="card-subtitle">
                                    <?php echo e($p->produk->relasi_kategori->nama); ?>

                                </div>
                                
                                <div class="description">
                                    Waktu Pengerjaan : <?php echo e($p->produk->waktu_pengerjaan); ?> hari
                                </div>
                                <div class="description" style="text-align: justify;">
                                    <br>
                                    Deskripsi :
                                    <br>
                                    <?php echo $p->produk->deskripsi; ?>

                                </div>
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="stories">
        <div class="d-flex flex-row justify-content-center align-items-center container">
            <img src="<?php echo e(asset('assets/frontend/images/details-image.png')); ?>" alt="semina" class="d-none d-lg-block"
                width="515" />
            <div class="d-flex flex-column">
                <div>
                    <div class="sub-title">
                        <span class="text-gradient-pink">Story</span>
                    </div>
                    <div class="title">
                        CV MITRA JAYA MELAYANI <br class="d-none d-lg-block" />
                        
                    </div>
                </div>
                <p class="paragraph">
                    Cv mitra jaya melayani hampir semua kebutuhan percetakan untuk bisnismu, pelayanan jasa kami pencetakan
                    produk. Pekerjaan kami dilakukan oleh tenaga profesional yang ahli dalam bidang nya
                    <br class="d-none d-lg-block" />
                </p>
                <a href="https://wa.me/<?php echo e($about->wa); ?>" class="btn-navy" target="_BLANK">HUBUNGI KAMI</a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app-home', ['about', 'metodePembayaran'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>