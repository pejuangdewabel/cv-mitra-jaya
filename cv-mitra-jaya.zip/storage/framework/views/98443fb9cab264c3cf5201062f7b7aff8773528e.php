 <header id="header" class="header fixed-top d-flex align-items-center">

     <div class="d-flex align-items-center justify-content-between">
         <a href="<?php echo e(route('dashboard-karyawan')); ?>" class="logo d-flex align-items-center">
             <img src="<?php echo e(asset('assets/frontend/images/Logo-new/plotter.png')); ?>" alt="">
             <span class="d-none d-lg-block">CV MITRA JAYA</span>
         </a>
         <?php if(auth()->guard('karyawan')->check()): ?>
             <i class="bi bi-list toggle-sidebar-btn"></i>
         <?php endif; ?>
     </div><!-- End Logo -->

     <nav class="header-nav ms-auto">
         <ul class="d-flex align-items-center">

             <li class="nav-item d-block d-lg-none">
                 <a class="nav-link nav-icon search-bar-toggle " href="#">
                     <i class="bi bi-search"></i>
                 </a>
             </li><!-- End Search Icon-->

             

             <li class="nav-item dropdown pe-3">
                 <?php if(auth()->guard('user')->check()): ?>
                     <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#"
                         data-bs-toggle="dropdown">
                         <img src="<?php echo e(asset('assets/backend/img/user-default.png')); ?>" alt="Profile"
                             class="rounded-circle">
                         <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo e(Auth::guard('user')->user()->nama); ?></span>
                     </a><!-- End Profile Iamge Icon -->
                 <?php endif; ?>

                 <?php if(auth()->guard('karyawan')->check()): ?>
                     <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#"
                         data-bs-toggle="dropdown">
                         <img src="<?php echo e(Storage::url(Auth::guard('karyawan')->user()->foto)); ?>" alt="Profile"
                             class="rounded-circle">
                         <span
                             class="d-none d-md-block dropdown-toggle ps-2"><?php echo e(Auth::guard('karyawan')->user()->nama); ?></span>
                     </a><!-- End Profile Iamge Icon -->
                 <?php endif; ?>

                 <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                     <?php if(auth()->guard('karyawan')->check()): ?>
                         <li class="dropdown-header">
                             <h6><?php echo e(Auth::guard('karyawan')->user()->nama); ?></h6>
                             <span>
                                 <?php if(Auth::guard('karyawan')->user()->level == 1): ?>
                                     ADMIN
                                 <?php elseif(Auth::guard('karyawan')->user()->level == 2): ?>
                                     OPERATOR
                                 <?php elseif(Auth::guard('karyawan')->user()->level == 3): ?>
                                     PIMPINAN
                                 <?php endif; ?>
                             </span>
                         </li>
                     <?php endif; ?>
                     <?php if(auth()->guard('user')->check()): ?>
                         <li class="dropdown-header">
                             <h6><?php echo e(Auth::guard('user')->user()->nama); ?></h6>
                             <span>
                                 <?php echo e(Auth::guard('user')->user()->level); ?>

                             </span>
                         </li>
                     <?php endif; ?>
                     <li>
                         <hr class="dropdown-divider">
                     </li>
                     <?php if(auth()->guard('karyawan')->check()): ?>
                         <li>
                             <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('setting-profile-admin')); ?>">
                                 <i class="bi bi-person"></i>
                                 <span>My Profile</span>
                             </a>
                         </li>
                     <?php endif; ?>
                     <?php if(auth()->guard('user')->check()): ?>
                         <li>
                             <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('dashboard-user')); ?>">
                                 <i class="bi bi-grid"></i>
                                 <span>Dashboard Home</span>
                             </a>
                         </li>
                         <li>
                             <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('user-setting')); ?>">
                                 <i class="bi bi-person"></i>
                                 <span>My Profile</span>
                             </a>
                         </li>
                     <?php endif; ?>
                     <li>
                         <hr class="dropdown-divider">
                     </li>
                     <li>
                         <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('logout')); ?>">
                             <i class="bi bi-box-arrow-right"></i>
                             <span>Sign Out</span>
                         </a>
                     </li>

                 </ul><!-- End Profile Dropdown Items -->
             </li><!-- End Profile Nav -->
         </ul>
     </nav><!-- End Icons Navigation -->

 </header>
<?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/includes/header.blade.php ENDPATH**/ ?>