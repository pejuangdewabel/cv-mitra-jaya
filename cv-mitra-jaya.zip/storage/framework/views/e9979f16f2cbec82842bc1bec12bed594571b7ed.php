<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
        <?php if(auth()->guard('karyawan')->check()): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('index/dashboard') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('dashboard-karyawan')); ?>">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>
            </li><!-- End Dashboard Nav -->
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('index/data*') ? '' : 'collapsed'); ?>" data-bs-target="#components-nav"
                    data-bs-toggle="collapse" href="#">
                    <i class="bi bi-menu-button-wide"></i><span>Data Master</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="components-nav"
                    class="nav-content <?php echo e(request()->is('index/data*') ? '' : 'collapse'); ?> <?php echo e(request()->is('index/data*') ? 'show' : ''); ?>"
                    data-bs-parent="#sidebar-nav">
                    <li>
                        <a href="<?php echo e(route('kategori.index')); ?>"
                            class="<?php echo e(request()->is('index/data/kategori*') ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Kategori Produk</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('produk.index')); ?>"
                            class="<?php echo e(request()->is('index/data/produk*') ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Produk</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('tentang.index')); ?>"
                            class="<?php echo e(request()->is('index/data/tentang*') ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Tentang</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('metode-pembayaran.index')); ?>"
                            class="<?php echo e(request()->is('index/data/metode-pembayaran*') ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Metode Pembayaran</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('user.index')); ?>"
                            class="<?php echo e(request()->is('index/data/user*') ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>User</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('karyawan.index')); ?>"
                            class="<?php echo e(request()->is('index/data/karyawan*') ? 'active' : ''); ?>">
                            <i class="bi bi-circle"></i><span>Karyawan</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('index/transaksi*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('transaksi.index')); ?>">
                    <i class="bi bi-box-arrow-in-right"></i>
                    <span>Data Transaksi</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('index/laporan*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('laporan-index')); ?>">
                    <i class="bi bi-file-earmark-bar-graph"></i>
                    <span>Laporan Transaksi</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if(auth()->guard('user')->check()): ?>
            <li class="nav-item">
                
                <a class="nav-link" href="#">
                    <i class="bi bi-file-earmark-bar-graph"></i>
                    <span>Dashboard</span>
                </a>
            </li>
        <?php endif; ?>

    </ul>

</aside>
<?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/includes/aside.blade.php ENDPATH**/ ?>