 <!-- Favicons -->
 <link href="<?php echo e(asset('assets/frontend/images/Logo-new/plotter.png')); ?>" rel="icon">
 <link href="<?php echo e(asset('assets/frontend/images/Logo-new/plotter.png')); ?>" rel="apple-touch-icon">

 <!-- Google Fonts -->
 <link href="https://fonts.gstatic.com" rel="preconnect">
 <link
     href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
     rel="stylesheet">

 <!-- Vendor CSS Files -->
 <link href="<?php echo e(asset('assets/backend/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/backend/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/backend/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/backend/vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/backend/vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/backend/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/backend/vendor/simple-datatables/style.css')); ?>" rel="stylesheet">

 <!-- Template Main CSS File -->
 <link href="<?php echo e(asset('assets/backend/css/style.css')); ?>" rel="stylesheet">
<?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/includes/link.blade.php ENDPATH**/ ?>