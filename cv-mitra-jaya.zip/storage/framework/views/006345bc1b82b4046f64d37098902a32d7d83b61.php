<?php $__env->startPush('after-link'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>USER | SISTEM MANAJEMEN PEMESANAN CV MITRA JAYA</h1>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-12">
                    <div class="card top-selling">
                        <div class="card-body pb-0">
                            <div class="card-title">
                                
                                DATA USER
                            </div>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">No Telp</th>
                                        <th scope="col">Alamat</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Level</th>
                                        <th scope="col">Foto</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dataUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dU): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($dU->email); ?></td>
                                            <td><?php echo e($dU->nama); ?></td>
                                            <td><?php echo e($dU->no_telp); ?></td>
                                            <td>
                                                <?php if($dU->alamat != null): ?>
                                                    <?php echo e($dU->alamat); ?>

                                                <?php else: ?>
                                                    ---
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($dU->status == 1): ?>
                                                    <span class="badge bg-primary">Aktif</span>
                                                <?php elseif($dU->status == 2): ?>
                                                    <span class="badge bg-danger">Tidak Aktif</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($dU->level); ?></td>
                                            <td>
                                                <?php if($dU->foto != null): ?>
                                                    <img src="<?php echo e(Storage::url($dU->foto)); ?>" class="img-thumbnail"
                                                        style="max-width: 100px !important">
                                                <?php else: ?>
                                                    ---
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('user.edit', Crypt::encryptString($dU->id))); ?>"
                                                    class="btn btn-warning">
                                                    <i class="bi bi-pencil-fill"></i>
                                                </a>
                                                <br>
                                                <br>
                                                <form action="<?php echo e(route('user.destroy', Crypt::encryptString($dU->id))); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/pages/user/index.blade.php ENDPATH**/ ?>