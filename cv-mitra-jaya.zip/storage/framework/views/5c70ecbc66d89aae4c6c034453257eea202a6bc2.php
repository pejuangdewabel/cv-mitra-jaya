<?php $__env->startPush('after-link'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Riwayat Laporan Transaksi | SISTEM MANAJEMEN PEMESANAN CV MITRA JAYA</h1>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-12">
                    <div class="card top-selling">
                        <div class="card-body pb-0">
                            <div class="card-title">
                                <form action="<?php echo e(route('laporan-filter')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="">Tanggal Awal</label>
                                            <input type="date" name="dateStart" class="form-control"
                                                value="<?php echo e($dateStart); ?>">
                                        </div>
                                        <div class="col-md-2">
                                            <label for="">Tanggal Akhir</label>
                                            <input type="date" name="dateEnd" class="form-control"
                                                value="<?php echo e($dateEnd); ?>">
                                        </div>
                                        <br>
                                        <br>
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-primary btn-sm mt-2">
                                                FILTER DATA
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <?php if($dataTransaksi != null): ?>
                                    <form action="<?php echo e(route('laporan-print')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="row mt-2">
                                            <input type="hidden" name="dateStart" class="form-control"
                                                value="<?php echo e($dateStart); ?>">
                                            <input type="hidden" name="dateEnd" class="form-control"
                                                value="<?php echo e($dateEnd); ?>">
                                            <div class="col-md-6">
                                                <button class="btn btn-success btn-sm" type="submit">CETAK LAPORAN</button>
                                            </div>
                                        </div>
                                    </form>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th scope="col">Invoice</th>
                                        <th scope="col">Tanggal Transaksi</th>
                                        <th scope="col">Nama Pelanggan</th>
                                        <th scope="col">Total</th>
                                        
                                        <th scope="col">Status</th>
                                        <th scope="col">Cetak</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dataTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($dT->invoice); ?></td>
                                            <td><?php echo e(tanggal_indonesia(date('Y-m-d', strtotime($dT->created_at)))); ?></td>
                                            <td><?php echo e($dT->relasi_user->nama); ?></td>
                                            <td><?php echo e(format_uang($dT->total)); ?></td>
                                            
                                            <td>
                                                <?php if($dT->status == 0): ?>
                                                    <span class="badge bg-danger">Belum Bayar</span>
                                                <?php elseif($dT->status == 1): ?>
                                                    <span class="badge bg-primary">Sudah Bayar</span>
                                                <?php elseif($dT->status == 2): ?>
                                                    <span class="badge bg-warning">Proses Pengerjaan</span>
                                                <?php elseif($dT->status == 3): ?>
                                                    <span class="badge bg-success">Selesai</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('laporan-invoice', Crypt::encryptString($dT->id))); ?>"
                                                    class="btn btn-primary btn-sm">
                                                    <i class="bi bi-printer"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/pages/laporan/index.blade.php ENDPATH**/ ?>