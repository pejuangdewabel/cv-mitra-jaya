<?php $__env->startPush('after-link'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Dashboard Pelanggan | SISTEM MANAJEMEN PEMESANAN CV MITRA JAYA</h1>
    </div>
    <div class="row">
        <?php $__currentLoopData = $listProduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3">
                <!-- Card with an image on top -->
                <div class="card">
                    <img src="<?php echo e(Storage::url($dpr->produk->foto)); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($dpr->desc); ?></h5>
                        <p><?php echo e($dpr->produk->relasi_kategori->nama); ?></p>
                        <p><span class="badge bg-primary"><?php echo e(format_uang($dpr->price)); ?></span></p>
                        <p>Terjual : <?php echo e(App\DetailTransaksi::where('produk_id_detail', $dpr->produk->id)->sum('jumlah')); ?>

                        </p>
                        <p>Waktu Pengerjaan : <?php echo e($dpr->produk->waktu_pengerjaan); ?> hari</p>
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#<?php echo e($dpr->produk->slug); ?>" aria-expanded="false"
                                        aria-controls="collapseOne">
                                        Deskripsi :
                                    </button>
                                </h2>
                                <div id="<?php echo e($dpr->produk->slug); ?>" class="accordion-collapse collapse"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
                                    <div class="accordion-body">
                                        <p class="card-text">
                                            <?php echo $dpr->produk->deskripsi; ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- End Card with an image on top -->
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($listProduk->links()); ?>

    </div>


    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-12">
                    <div class="card top-selling">
                        <div class="card-body pb-0">
                            <h5 class="card-title">Form Checkout Transaksi</h5>
                            <form class="row g-3" method="POST" action="<?php echo e(route('dashboard-checkout')); ?>"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e(Crypt::encryptString(Auth::guard('user')->user()->id)); ?>"
                                    name="user_id">
                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <select name="produk_id" id="produk_id" class="form-select js-example-basic-single"
                                            required>
                                            <option disabled selected></option>
                                            <?php $__currentLoopData = $dataProduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dP->id); ?>"><?php echo e($dP->desc); ?> |
                                                    <?php echo e(format_uang($dP->price)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        
                                        <?php $__errorArgs = ['produk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-exclamation-octagon me-1"></i>
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" name="size1" id="size1"
                                            placeholder="Size Awal" required value="0">
                                        <label for="size1">Panjang</label>
                                        <?php $__errorArgs = ['size1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-exclamation-octagon me-1"></i>
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" name="size2" id="size2"
                                            placeholder="Size Akhir" required value="0">
                                        <label for="size2">Lebar</label>
                                        <?php $__errorArgs = ['size2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-exclamation-octagon me-1"></i>
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" name="jumlah" id="jumlah"
                                            placeholder="Jumlah" required value="<?php echo e(old('jumlah')); ?>">
                                        <label for="jumlah">Jumlah</label>
                                        <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-exclamation-octagon me-1"></i>
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-floating">
                                        <input type="file" class="form-control" name="file_desain" id="file_desain"
                                            placeholder="FIie Desain">
                                        <label for="file_desain">File Desain</label>
                                        <?php $__errorArgs = ['file_desain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-exclamation-octagon me-1"></i>
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" name="ket" id="ket"
                                            placeholder="Keterangan">
                                        <label for="ket">Keterangan</label>
                                        <?php $__errorArgs = ['ket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-exclamation-octagon me-1"></i>
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary w-100">Simpan</button>
                                </div>
                            </form>
                            <hr>

                            <h5 class="card-title">Keranjang Transaksi</h5>

                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Produk</th>
                                        <th scope="col">Jumlah</th>
                                        <th scope="col">Harga</th>
                                        <th scope="col">Sub Total</th>
                                        <th scope="col">Ukuran</th>
                                        <th scope="col">File Desain</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(empty($keranjang)): ?>
                                        <tr>
                                            <th>
                                                ---
                                            </th>
                                            <td>
                                                ---
                                            </td>
                                            <td>
                                                ---
                                            </td>
                                            <td>
                                                ---
                                            </td>
                                            <td>
                                                ---
                                            </td>
                                            <td>
                                                ---
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row">
                                                    <?php echo e($loop->iteration); ?>

                                                </th>
                                                <td>
                                                    <?php echo e($k->relasi_produk_detail->desc); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($k->jumlah); ?>

                                                </td>
                                                <td>
                                                    <?php echo e(format_uang($k->relasi_produk_detail->price)); ?>

                                                </td>
                                                <td class="fw-bold text-right">
                                                    <?php echo e(format_uang($k->sub_total)); ?>

                                                </td>
                                                <td class="fw-bold text-right">
                                                    <?php echo e($k->ket); ?>

                                                </td>
                                                <td>
                                                    <?php if($k->file_desain): ?>
                                                        <form action="<?php echo e(route('download-file-user')); ?>" method="post"
                                                            enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id"
                                                                value="<?php echo e(Crypt::encryptString($k->id)); ?>">
                                                            <button type="submit" class="btn btn-success btn-sm"
                                                                target="_blank">
                                                                <i class="bi bi-capslock-fill"></i>
                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        ---
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <form
                                                        action="<?php echo e(route('delete-checkout', Crypt::encryptString($k->id))); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="4" class="fw-bold text-left">Total Pembayaran</td>
                                            <td class="fw-bold text-right"><?php echo e(format_uang($countKeranjang)); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    
                                </tbody>
                            </table>
                            <hr>
                            <?php if($keranjang->isEmpty()): ?>
                            <?php else: ?>
                                <form class="row g-3" action="<?php echo e(route('process-checkout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-4">
                                        <div class="form-floating">
                                            <select name="metodePembayaran" id="metodePembayaran" class="form-select"
                                                required>
                                                <option selected disabled>PILIH</option>
                                                <?php $__currentLoopData = $metodePembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($mP->id); ?>"><?php echo e($mP->nama_pembayaran); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="metodePembayaran">Metode Pembayaran</label>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success w-100">SELESAIKAN TRANSAKSI</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-12">
                    <div class="card top-selling">
                        <div class="card-body pb-0">
                            <h5 class="card-title">List Riwayat Transaksi</h5>
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th scope="col">Invoice</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Detail</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <th scope="row">
                                                <?php echo e($dP->invoice); ?>

                                            </th>
                                            <td>
                                                <?php echo e(format_uang($dP->total)); ?>

                                            </td>
                                            <td class="fw-bold">
                                                <?php if($dP->status == 0): ?>
                                                    <span class="badge bg-danger">Belum Bayar</span>
                                                <?php elseif($dP->status == 1): ?>
                                                    <span class="badge bg-primary">Sudah Bayar</span>
                                                <?php elseif($dP->status == 2): ?>
                                                    <span class="badge bg-warning">Proses Pengerjaan</span>
                                                <?php elseif($dP->status == 3): ?>
                                                    <span class="badge bg-success">Selesai</span>
                                                <?php elseif($dP->status == 4): ?>
                                                    <span class="badge bg-danger">Bukti Pembayaran Ditolak</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($dP->status != 4): ?>
                                                    <a href="<?php echo e(route('detail-transaksi', Crypt::encryptString($dP->id))); ?>"
                                                        class="btn btn-primary btn-sm">Lihat</a>
                                                    <?php if($dP->status >= 1): ?>
                                                        <a href="<?php echo e(route('cetak-invoice-user', Crypt::encryptString($dP->id))); ?>"
                                                            class="btn btn-success btn-sm" target="_BLANK">Print
                                                            Invoice</a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    ---
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <th>---</th>
                                            <td>---</td>
                                            <td>---</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-script'); ?>
    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI="
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#produk_id').select2({
                placeholder: "Pilih Produk",
                allowClear: true,
                width: 'resolve',
                theme: "classic"
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/pages/user-pengguna/dashboard.blade.php ENDPATH**/ ?>