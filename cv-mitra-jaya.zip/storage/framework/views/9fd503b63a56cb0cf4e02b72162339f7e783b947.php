<?php $__env->startPush('after-link'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="login header bg-navy">
        <div class="container">
            <div class="d-flex flex-column align-items-center hero gap-5">
                <div>
                    <div class="hero-headline text-start">
                        Silahkan Masuk
                    </div>
                </div>
                <form action="<?php echo e(route('check-login')); ?>" method="POST"
                    class="form-login d-flex flex-column mt-4 mt-md-0 p-30">
                    <?php echo csrf_field(); ?>
                    <!-- Email -->
                    <div class="d-flex flex-column align-items-start">
                        <label for="email_address" class="form-label">
                            Email
                        </label>
                        <input type="text" class="form-control" id="email" name="email"
                            placeholder="Masukkan Email">
                    </div>
                    <!-- Password -->
                    <div class="d-flex flex-column align-items-start">
                        <label for="password" class="form-label">
                            Password (6 characters)
                        </label>
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="Masukkan password">
                    </div>
                    <div class="d-grid mt-2 gap-4">
                        <button type="submit" class="btn-green">
                            MASUK
                        </button>
                        <a href="<?php echo e(route('register')); ?>" class="btn-navy">
                            DAFTAR
                        </a>
                    </div>
                </form>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/frontend/pages/auth/login.blade.php ENDPATH**/ ?>