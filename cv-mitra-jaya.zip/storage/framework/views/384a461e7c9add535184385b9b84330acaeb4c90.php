<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span id="dateNow"></span></strong>
    </div>
</footer>
<?php /**PATH E:\Coding\Laravel-Skripsi\cv-mitra-jaya\resources\views/backend/includes/footer.blade.php ENDPATH**/ ?>