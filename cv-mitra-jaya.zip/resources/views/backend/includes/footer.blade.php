<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span id="dateNow"></span></strong>
    </div>
</footer>
