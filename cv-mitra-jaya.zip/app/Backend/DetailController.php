<?php

namespace App\Backend;

use Illuminate\Database\Eloquent\Model;

class DetailController extends Model
{
    //
}
