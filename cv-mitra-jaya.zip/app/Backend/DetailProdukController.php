<?php

namespace App\Backend;

use Illuminate\Database\Eloquent\Model;

class DetailProdukController extends Model
{
    //
}
